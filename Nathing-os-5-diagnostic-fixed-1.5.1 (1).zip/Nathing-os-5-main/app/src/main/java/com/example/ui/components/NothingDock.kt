package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppItem
import com.example.model.IconPackStyle
import com.example.ui.theme.LocalLauncherTheme
import com.example.ui.theme.NothingBorder
import com.example.ui.theme.NothingDarkSurface
import com.example.ui.theme.NothingElevated
import com.example.ui.theme.NothingGrey
import com.example.ui.theme.NothingRed
import com.example.ui.theme.NothingWhite

@Composable
fun NothingDock(
  dockApps: List<AppItem>,
  onAppClick: (AppItem) -> Unit,
  onOpenDrawer: () -> Unit,
  onOpenSearch: () -> Unit,
  searchQuery: String = "",
  onSearchChange: (String) -> Unit = {},
  modifier: Modifier = Modifier,
  iconPack: IconPackStyle = IconPackStyle.MONOCHROME,
  accentColor: Color = NothingRed,
  showSearchBar: Boolean = true,
  iconSize: androidx.compose.ui.unit.Dp = 52.dp,
  onToggleDockApp: ((AppItem) -> Unit)? = null,
  onOpenAppInfo: ((AppItem) -> Unit)? = null,
  onCycleIconSize: (() -> Unit)? = null
) {
  val theme = LocalLauncherTheme.current

  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 6.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    // Dock Icons Container - iOS Frosted Glass Blur Pill
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .pointerInput(onOpenDrawer) {
          var upwardDrag = 0f
          detectVerticalDragGestures(
            onVerticalDrag = { change, dragAmount ->
              change.consume()
              upwardDrag += dragAmount
              if (upwardDrag < -60f) {
                onOpenDrawer()
                upwardDrag = 0f
              }
            },
            onDragEnd = { upwardDrag = 0f },
            onDragCancel = { upwardDrag = 0f }
          )
        }
        .clip(RoundedCornerShape(32.dp))
        .background(
          if (theme.isDark) Color(0xDD1C1C1E) else Color(0xE8F4F4F6)
        )
        .border(
          width = 1.dp,
          color = if (theme.isDark) Color(0x33FFFFFF) else Color(0x1F000000),
          shape = RoundedCornerShape(32.dp)
        )
        .padding(horizontal = 8.dp, vertical = 7.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Four pinned apps leave room for the always-visible App Drawer button.
        dockApps.take(4).forEach { app ->
          AppIconItem(
            app = app,
            onClick = { onAppClick(app) },
            onOpenAppInfo = onOpenAppInfo,
            onToggleDock = onToggleDockApp,
            onCycleIconSize = onCycleIconSize,
            iconSize = iconSize,
            showLabel = false,
            iconPack = iconPack,
            accentColor = accentColor
          )
        }

        // Dedicated App Drawer button: this was missing from the visible dock.
        Box(
          modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .clickable { onOpenDrawer() }
            .testTag("nothing_open_app_drawer"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Apps,
            contentDescription = "Open app drawer",
            tint = accentColor,
            modifier = Modifier.size(25.dp)
          )
        }
      }
    }

    if (showSearchBar) {
      Spacer(modifier = Modifier.height(10.dp))

      // Signature Nothing Search Pill (Matches Image 3 rounded search pill)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .height(44.dp)
          .clip(RoundedCornerShape(22.dp))
          .background(theme.searchPillBg)
          .border(1.dp, theme.border, RoundedCornerShape(22.dp))
          .clickable { onOpenSearch() }
          .padding(horizontal = 16.dp)
          .testTag("nothing_search_pill"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Search,
          contentDescription = "Search",
          tint = theme.textSecondary,
          modifier = Modifier.size(18.dp)
        )
        BasicTextField(
          value = searchQuery,
          onValueChange = onSearchChange,
          singleLine = true,
          textStyle = androidx.compose.ui.text.TextStyle(
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            color = theme.textPrimary,
            letterSpacing = 1.sp
          ),
          modifier = Modifier
            .weight(1f)
            .testTag("nothing_search_input"),
          decorationBox = { innerTextField ->
            Box {
              if (searchQuery.isEmpty()) {
                Text(
                  text = if (!theme.isDark) "Search" else "SEARCH OR TYPE URL...",
                  fontFamily = FontFamily.Monospace,
                  fontSize = 12.sp,
                  color = theme.textSecondary,
                  letterSpacing = 1.sp
                )
              }
              innerTextField()
            }
          }
        )
        Box(
          modifier = Modifier
            .size(6.dp)
            .clip(CircleShape)
            .background(if (!theme.isDark) Color(0xFF4CAF50) else accentColor)
        )
      }
    }
  }
}
