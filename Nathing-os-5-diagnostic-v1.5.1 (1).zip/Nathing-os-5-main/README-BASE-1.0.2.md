# Nathing-os-5 — base reference: Nothing Launcher 1.0.2

This archive keeps the user's original Nothing Launcher 1.0.2 APK in `reference/Nothing-Launcher-1.0.2-original.apk` for reference. The APK is an original binary and is **not** the source code for this Android Studio project.

## Build workflow correction

- GitHub Actions now configures JDK 21 to match `app/build.gradle.kts`, which sets Java source/target compatibility to 21.
- The workflow still generates the Gradle wrapper with Gradle 9.3.1 when no wrapper is committed.

## Important status

This is a source project plus the original APK reference. The source project's current Gradle application ID is `com.example` and its version name is `1.5.0`; it is not a decompiled/rebuilt copy of the original `com.nothing.launcher` app. These identifiers have deliberately not been silently changed, because doing so would not make this source equivalent to the original launcher and could introduce more issues.

The workflow change is a targeted fix for the JDK mismatch. A successful APK build and Pixel 8 / Android 17 runtime compatibility still need confirmation from the GitHub Actions build and device testing.
