# Nathing OS Launcher 1.5.3

## Added
- New `SYSTEM / MONET` appearance option in launcher customization.
- On Android 12+, this option uses the device's Material You dynamic color palette.
- Automatically follows the Android system light/dark setting. On older Android versions it falls back to the launcher's built-in light/dark palette.
- Existing theme choices remain available.

## Build status
Source change only. This archive has not been compiled or device-tested in this environment. Build with GitHub Actions before installing.
