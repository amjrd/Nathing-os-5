# Launcher3 integration — Phase 2

This is a small source patch for the existing Compose-based Nathing OS launcher. It does not import the full AOSP Launcher3/Quickstep tree.

## Changes

- Uses `AppCatalogRepository` to enumerate launchable activities as components, deduplicating entries and sorting labels consistently.
- Launches the exact launcher activity represented by an icon instead of relying on `getLaunchIntentForPackage()`.
- Persists the selected Dock package order in `SharedPreferences` so a package refresh or launcher restart does not reset the Dock to the first five apps.
- Reconciles saved Dock entries against installed apps after package changes and falls back safely if saved entries are no longer installed.
- Keeps the existing Nothing/Compose UI and public Android SDK APIs. No privileged Quickstep code is introduced.

## Apply manually

Copy these files into the matching paths in the repository, replacing `LauncherViewModel.kt` and adding `AppCatalogRepository.kt`:

- `app/src/main/java/com/example/viewmodel/LauncherViewModel.kt`
- `app/src/main/java/com/example/launcher3/AppCatalogRepository.kt`

No nested project ZIPs are included. After committing, run the repository's existing Android CI build. This patch has not been built or tested on a physical Android 17 device in this environment.

## Important architecture note

This is an incremental integration step, not a full AOSP Launcher3 port. A full port requires adapting Launcher3's Android.bp/AOSP build modules, resources, launcher database, workspace model, and potentially Quickstep/system dependencies to a standalone Gradle application. That work should be separated into small, build-verified changes.
