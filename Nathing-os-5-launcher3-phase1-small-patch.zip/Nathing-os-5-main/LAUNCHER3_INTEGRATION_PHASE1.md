# Launcher3 integration — Phase 1

This patch starts the integration without replacing the existing Nothing/Compose UI.

## Changes
- Adds `com.example.launcher3.AppCatalogRepository`.
- Uses a launchable **activity component** (`packageName + activityName`) as app identity.
- Deduplicates launcher activities and sorts deterministically.
- Launches the selected activity component instead of relying only on
  `getLaunchIntentForPackage`, which can launch a different activity in packages with
  multiple launcher entries.
- Refreshes app discovery after package changes and preserves existing dock/pinned
  selections where those packages remain installed.

## Why this is a first phase, not the full AOSP source merge
AOSP Launcher3 is not a small Android library. Its official Android 17 build definition
includes framework-generated flags, Dagger, protobufs, SystemUI libraries and a separate
Quickstep path; the platform/privileged Quickstep pieces cannot simply be dropped into an
ordinary Compose APK. This phase deliberately uses public Android SDK APIs and preserves
the current project so that app discovery and launch behavior can be improved safely.

Official reference: https://android.googlesource.com/platform/packages/apps/Launcher3/+/refs/tags/android-17.0.0_r1/Android.bp

## Next integration stages
1. Build and validate this phase on the repository's Android Gradle environment.
2. Replace the current simulated workspace model with a persistent component-based model
   (workspace items, screen/cell coordinates, folders and app shortcuts).
3. Add real Android `AppWidgetHost` placement/resize flow and widget binding.
4. Only then decide whether to port additional AOSP Launcher3 UI/model modules or keep the
   Compose front end over a Launcher3-inspired core. Do not import Quickstep/platform-only
   source into the app module without its platform build environment.

## Validation status
Source patch generated; no Gradle build or device test was run in this environment. Do not
mark this version as build-verified until GitHub Actions/Android Studio reports success.
