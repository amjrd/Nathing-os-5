# Nathing OS 5 Launcher — implementation notes

## Preserved base and scope
- The original Nothing Launcher 1.0.2 APK is retained unchanged in `reference/` for analysis/reference only.
- This repository is a separate Kotlin/Jetpack Compose launcher project; it is not a rebuild or a binary patch of the original APK.
- The app ID remains `com.example` to avoid silently changing install/update identity.

## Theme work in this revision
- `ORIGINAL` theme now follows Android's system light/dark setting automatically.
- On Android 12 (API 31) and newer, `ORIGINAL` uses the wallpaper-derived Material You dynamic color scheme.
- On older Android versions, it falls back to the launcher's built-in light/dark Nothing-inspired schemes.
- The STUDIO, AURA and GLYPH presets remain explicit, fixed styles.

## Build verification
- GitHub Actions workflow is configured to use JDK 21 and run unit/Robolectric tests and assemble a debug APK.
- This environment does not have Gradle/Android SDK available for a local Android build, so compilation and Pixel 8 / Android 17 runtime behavior must be confirmed by the GitHub Actions run and device testing.
- The original 1.0.2 APK is not modified or repackaged by this project.
