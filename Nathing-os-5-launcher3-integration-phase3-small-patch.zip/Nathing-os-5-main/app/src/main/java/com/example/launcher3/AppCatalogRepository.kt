package com.example.launcher3

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import com.example.model.AppItem
import java.util.Locale

/** Launcher3-inspired app catalog implemented with public Android SDK APIs. */
class AppCatalogRepository(context: Context) {
    private val appContext = context.applicationContext
    private val packageManager = appContext.packageManager

    fun loadApps(): List<AppItem> {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val results = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.queryIntentActivities(query, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            packageManager.queryIntentActivities(query, 0)
        }
        val unique = LinkedHashMap<ComponentName, AppItem>()
        for (resolveInfo in results) {
            val activity = resolveInfo.activityInfo ?: continue
            if (!activity.enabled || !activity.applicationInfo.enabled) continue
            if (activity.packageName == appContext.packageName) continue
            val component = ComponentName(activity.packageName, activity.name)
            val label = resolveInfo.loadLabel(packageManager)?.toString()
                ?.trim()?.takeIf { it.isNotEmpty() } ?: activity.packageName
            unique[component] = AppItem(
                packageName = activity.packageName,
                activityName = activity.name,
                label = label,
                iconDrawable = resolveInfo.loadIcon(packageManager),
                category = categorize(label, activity.packageName)
            )
        }
        return unique.values.sortedWith(
            compareBy<AppItem> { it.label.lowercase(Locale.ROOT) }
                .thenBy { it.packageName }
                .thenBy { it.activityName }
        )
    }

    fun launch(app: AppItem): Boolean {
        if (app.activityName.isBlank()) return false
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(app.packageName, app.activityName))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            appContext.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun categorize(label: String, packageName: String): String {
        val value = "$label $packageName".lowercase(Locale.ROOT)
        return when {
            listOf("game", "play games").any(value::contains) -> "Games"
            listOf("whatsapp", "telegram", "signal", "chat", "messages").any(value::contains) -> "Communication"
            listOf("gmail", "mail", "calendar", "docs", "drive", "office").any(value::contains) -> "Work"
            listOf("camera", "photos", "gallery", "youtube", "music").any(value::contains) -> "Media"
            else -> "Apps"
        }
    }
}
