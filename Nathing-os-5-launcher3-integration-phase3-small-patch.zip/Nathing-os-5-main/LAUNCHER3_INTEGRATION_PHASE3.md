# Nathing OS — Launcher3 integration phase 3

## Scope
This patch improves the real app catalog and Dock behavior in the existing Compose-based Nathing OS project. It is intentionally small and contains no nested ZIP archives.

## Files in this patch
- `app/src/main/java/com/example/launcher3/AppCatalogRepository.kt` — discovers enabled launcher activities, uses component identity, sorts deterministically, and launches the selected component.
- `app/src/main/java/com/example/viewmodel/LauncherViewModel.kt` — loads the catalog off the UI thread, publishes state on the main thread, remembers Dock component order, refreshes the catalog after package changes, and retries catalog discovery if an app can no longer be launched.

## Apply
Upload/replace these two files at exactly the same paths in the repository. Add this Markdown file at the repository root. Do not delete any other source files.

## Why this is an important foundation
Launcher3 models launchable activities as components and maintains a distinction between the app catalog and workspace choices. This patch applies those principles using public Android APIs, while preserving the current Nothing UI and avoiding privileged Quickstep/system dependencies.

## Not yet included
This is not a full AOSP Launcher3 port and does not yet provide persistent workspace cell positions, drag-and-drop placement, real Android widget binding/resizing, or Quickstep recents/gesture integration. Those require separate steps and validation. AOSP Launcher3's platform build files cannot simply be copied into this app's Gradle project.

## Validation
Static source review only. No Gradle build or physical-device test was run in this environment. After committing, run the repository's GitHub Actions build and share the result before proceeding to workspace persistence.
